﻿Imports System.Windows.Threading
Imports System.Collections.ObjectModel
Imports System.ComponentModel

Public Class LongRenderingModelView
    Implements INotifyPropertyChanged

    Private _data As New ObservableCollection(Of String)
    Private _refreshCmd As New RefreshCommand(Me)
    Private _buttonText As String = "Refresh data"
    Private _isButtonEnabled As Boolean = True

    ''' <summary>
    ''' Command for refreshing data set
    ''' </summary>
    Public ReadOnly Property RefreshCmd() As RefreshCommand
        Get
            Return _refreshCmd
        End Get
    End Property

    ''' <summary>
    ''' The large data set to be rendered in the UI
    ''' </summary>
    Public ReadOnly Property Data() As ObservableCollection(Of String)
        Get
            Return _data
        End Get
    End Property

    ''' <summary>
    ''' Clears <c>Data</c> and then inserts a whole bunch of strings.
    ''' </summary>
    Private Sub RefreshData()

        ButtonText = "Loading..."
        IsButtonEnabled = False

        Data.Clear()
        For i = 0 To 1000
            Data.Add(i.ToString)

            ' Wait for rendering to complete before continuing
            FlushWindowsMessageQueue()
        Next

        ButtonText = "RefreshData"
        IsButtonEnabled = True

    End Sub

    ''' <summary>
    ''' Forces all the items in the windows message queue to be dealt with.  ie: the function blocks
    ''' until rendering is complete.
    ''' </summary>
    Private Sub FlushWindowsMessageQueue()
        Application.Current.Dispatcher.Invoke(New Action(AddressOf DummySub), DispatcherPriority.Background, New Object() {})
    End Sub

    Private Sub DummySub()
    End Sub

    Public Property ButtonText() As String
        Get
            Return _buttonText
        End Get
        Private Set(ByVal value As String)
            _buttonText = value
            RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs("ButtonText"))
        End Set
    End Property

    Public Property IsButtonEnabled() As Boolean
        Get
            Return _isButtonEnabled
        End Get
        Private Set(ByVal value As Boolean)
            _isButtonEnabled = value
            RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs("IsButtonEnabled"))
        End Set
    End Property

    ''' <summary>
    ''' Command for refreshing <c>LongRenderingModelView.Data</c>.
    ''' </summary>
    Public Class RefreshCommand
        Implements ICommand

        Private _longRenderingModelView As LongRenderingModelView

        Public Sub New(ByVal longRenderingModelView As LongRenderingModelView)
            _longRenderingModelView = longRenderingModelView
        End Sub

        Public Function CanExecute(ByVal parameter As Object) As Boolean Implements System.Windows.Input.ICommand.CanExecute
            Return True
        End Function

        Public Event CanExecuteChanged(ByVal sender As Object, ByVal e As System.EventArgs) Implements System.Windows.Input.ICommand.CanExecuteChanged

        Public Sub Execute(ByVal parameter As Object) Implements System.Windows.Input.ICommand.Execute
            _longRenderingModelView.RefreshData()
        End Sub
    End Class

    Public Event PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged
End Class
