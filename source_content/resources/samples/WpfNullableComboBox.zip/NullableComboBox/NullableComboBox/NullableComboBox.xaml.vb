﻿Imports System.Collections.ObjectModel

''' <summary>
''' This class acts as a wrapper around <c>ComboBox</c> and adds a null option.
''' </summary>
''' <remarks>You can change how the null option is displayed by putting a <c>DataTemplate</c>
''' on <c>NullableComboBox+NullPlaceholder</c>.  Since the extra element in the combo box's
''' collection is the singleton instance of <c>NullableComboBox+NullPlaceholder</c>, it is
''' actually converted back into <c>Nothing</c> in <c>NullableComboBox.SelectedItem</c> so
''' that client code will just see it as <c>Nothing</c>.</remarks>
Partial Public Class NullableComboBox

#Region "Wrappers for SelectedItem and ItemsSource"
    ''' <summary>
    ''' Pretty much just a simple wrapper around <c>ComboBox.SelectedItem</c>, but on
    ''' the underlying <c>ComboBox</c> <c>Nothing</c> is replaced by the singleton
    ''' instance of <c>NullPlaceholder</c>.
    ''' </summary>
    Public Property SelectedItem() As Object
        Get
            Return GetValue(SelectedItemProperty)
        End Get
        Set(ByVal value As Object)
            SetValue(SelectedItemProperty, value)
            If value Is Nothing Then combo.SelectedItem = NullPlaceholder.Instance
        End Set
    End Property

    Public Shared ReadOnly SelectedItemProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectedItem", _
                           GetType(Object), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(NullPlaceholder.Instance, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, AddressOf OnDependencyPropertyChanged))

    ''' <summary>
    ''' Wraps <c>ComboBox.ItemsSource</c>, but adds the singleton instance of
    ''' <c>ComboBox.SelectedItem</c> to the list.
    ''' </summary>
    Public Property ItemsSource() As IEnumerable
        Get
            Return GetValue(ItemsSourceProperty)
        End Get
        Set(ByVal value As IEnumerable)
            SetValue(ItemsSourceProperty, value)

            ' Set the items source for the actual combo box
            Dim listWithNull As New List(Of Object)
            listWithNull.Add(NullPlaceholder.Instance)
            For Each element In value
                listWithNull.Add(element)
            Next
            combo.ItemsSource = listWithNull
        End Set
    End Property

    Public Shared ReadOnly ItemsSourceProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemsSource", _
                           GetType(IEnumerable), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(Nothing, AddressOf OnDependencyPropertyChanged))

    Private Shared Sub OnDependencyPropertyChanged(ByVal obj As DependencyObject, ByVal args As DependencyPropertyChangedEventArgs)
        Dim self = DirectCast(obj, NullableComboBox)
        If args.Property Is SelectedItemProperty Then
            self.SelectedItem = args.NewValue
        ElseIf args.Property Is ItemsSourceProperty Then
            self.ItemsSource = DirectCast(args.NewValue, IEnumerable)
        End If
    End Sub

    Private Sub combo_SelectionChanged(ByVal sender As Object, ByVal e As System.Windows.Controls.SelectionChangedEventArgs) Handles combo.SelectionChanged
        ' The property the is bound to NullableComboBox.SelectedItem needs to be set to Nothing when the
        ' null option is chosen, not NullPlaceholder.Instance, so convert it here if necessary
        If TypeOf combo.SelectedItem Is NullPlaceholder Then
            SelectedItem = Nothing
        Else
            SelectedItem = combo.SelectedItem
        End If
    End Sub
#End Region

#Region "Uninteresting ComboBox wrapper properties"
    Public Property AlternationCount() As Integer
        Get
            Return GetValue(AlternationCountProperty)
        End Get

        Set(ByVal value As Integer)
            SetValue(AlternationCountProperty, value)
        End Set
    End Property

    Public Shared ReadOnly AlternationCountProperty As DependencyProperty = _
                           DependencyProperty.Register("AlternationCount", _
                           GetType(Integer), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.AlternationCountProperty.DefaultMetadata.DefaultValue))



    Public Property DisplayMemberPath() As String
        Get
            Return GetValue(DisplayMemberPathProperty)
        End Get

        Set(ByVal value As String)
            SetValue(DisplayMemberPathProperty, value)
        End Set
    End Property

    Public Shared ReadOnly DisplayMemberPathProperty As DependencyProperty = _
                           DependencyProperty.Register("DisplayMemberPath", _
                           GetType(String), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.DisplayMemberPathProperty.DefaultMetadata.DefaultValue))


    Public ReadOnly Property GroupStyle() As ObservableCollection(Of GroupStyle)
        Get
            Return combo.GroupStyle
        End Get
    End Property


    Public Property GroupStyleSelector() As GroupStyleSelector
        Get
            Return GetValue(GroupStyleSelectorProperty)
        End Get

        Set(ByVal value As GroupStyleSelector)
            SetValue(GroupStyleSelectorProperty, value)
        End Set
    End Property

    Public Shared ReadOnly GroupStyleSelectorProperty As DependencyProperty = _
                           DependencyProperty.Register("GroupStyleSelector", _
                           GetType(GroupStyleSelector), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.GroupStyleSelectorProperty.DefaultMetadata.DefaultValue))


    Public ReadOnly Property HasItems() As Boolean
        Get
            Return combo.HasItems
        End Get
    End Property

    Public Shared ReadOnly HasItemsProperty As DependencyProperty = _
                           DependencyProperty.Register("HasItems", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.HasItemsProperty.DefaultMetadata.DefaultValue))



    Public Property IsDropDownOpen() As Boolean
        Get
            Return GetValue(IsDropDownOpenProperty)
        End Get

        Set(ByVal value As Boolean)
            SetValue(IsDropDownOpenProperty, value)
        End Set
    End Property

    Public Shared ReadOnly IsDropDownOpenProperty As DependencyProperty = _
                           DependencyProperty.Register("IsDropDownOpen", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.IsDropDownOpenProperty.DefaultMetadata.DefaultValue))



    Public Property IsEditable() As Boolean
        Get
            Return GetValue(IsEditableProperty)
        End Get

        Set(ByVal value As Boolean)
            SetValue(IsEditableProperty, value)
        End Set
    End Property

    Public Shared ReadOnly IsEditableProperty As DependencyProperty = _
                           DependencyProperty.Register("IsEditable", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.IsEditableProperty.DefaultMetadata.DefaultValue))



    Public Property IsReadOnly() As Boolean
        Get
            Return GetValue(IsReadOnlyProperty)
        End Get

        Set(ByVal value As Boolean)
            SetValue(IsReadOnlyProperty, value)
        End Set
    End Property

    Public Shared ReadOnly IsReadOnlyProperty As DependencyProperty = _
                           DependencyProperty.Register("IsReadOnly", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.IsReadOnlyProperty.DefaultMetadata.DefaultValue))



    Public Property IsSynchronizedWithCurrentItem() As Boolean?
        Get
            Return GetValue(IsSynchronizedWithCurrentItemProperty)
        End Get

        Set(ByVal value As Boolean?)
            SetValue(IsSynchronizedWithCurrentItemProperty, value)
        End Set
    End Property

    Public Shared ReadOnly IsSynchronizedWithCurrentItemProperty As DependencyProperty = _
                           DependencyProperty.Register("IsSynchronizedWithCurrentItem", _
                           GetType(Boolean?), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.IsSynchronizedWithCurrentItemProperty.DefaultMetadata.DefaultValue))



    Public Property IsTextSearchEnabled() As Boolean
        Get
            Return GetValue(IsTextSearchEnabledProperty)
        End Get

        Set(ByVal value As Boolean)
            SetValue(IsTextSearchEnabledProperty, value)
        End Set
    End Property

    Public Shared ReadOnly IsTextSearchEnabledProperty As DependencyProperty = _
                           DependencyProperty.Register("IsTextSearchEnabled", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.IsTextSearchEnabledProperty.DefaultMetadata.DefaultValue))



    Public Property ItemBindingGroup() As BindingGroup
        Get
            Return GetValue(ItemBindingGroupProperty)
        End Get

        Set(ByVal value As BindingGroup)
            SetValue(ItemBindingGroupProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemBindingGroupProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemBindingGroup", _
                           GetType(BindingGroup), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemBindingGroupProperty.DefaultMetadata.DefaultValue))


    Public ReadOnly Property ItemContainerGenerator() As ItemContainerGenerator
        Get
            Return combo.ItemContainerGenerator
        End Get
    End Property


    Public Property ItemContainerStyle() As Style
        Get
            Return GetValue(ItemContainerStyleProperty)
        End Get

        Set(ByVal value As Style)
            SetValue(ItemContainerStyleProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemContainerStyleProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemContainerStyle", _
                           GetType(Style), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemContainerStyleProperty.DefaultMetadata.DefaultValue))



    Public Property ItemContainerStyleSelector() As StyleSelector
        Get
            Return GetValue(ItemContainerStyleSelectorProperty)
        End Get

        Set(ByVal value As StyleSelector)
            SetValue(ItemContainerStyleSelectorProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemContainerStyleSelectorProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemContainerStyleSelector", _
                           GetType(StyleSelector), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemContainerStyleSelectorProperty.DefaultMetadata.DefaultValue))


    Public ReadOnly Property Items() As ItemCollection
        Get
            Return combo.Items
        End Get
    End Property


    Public Property ItemsPanel() As ItemsPanelTemplate
        Get
            Return GetValue(ItemsPanelProperty)
        End Get

        Set(ByVal value As ItemsPanelTemplate)
            SetValue(ItemsPanelProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemsPanelProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemsPanel", _
                           GetType(ItemsPanelTemplate), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemsPanelProperty.DefaultMetadata.DefaultValue))



    Public Property ItemStringFormat() As String
        Get
            Return GetValue(ItemStringFormatProperty)
        End Get

        Set(ByVal value As String)
            SetValue(ItemStringFormatProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemStringFormatProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemStringFormat", _
                           GetType(String), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemStringFormatProperty.DefaultMetadata.DefaultValue))



    Public Property ItemTemplate() As DataTemplate
        Get
            Return GetValue(ItemTemplateProperty)
        End Get

        Set(ByVal value As DataTemplate)
            SetValue(ItemTemplateProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ItemTemplateProperty As DependencyProperty = _
                           DependencyProperty.Register("ItemTemplate", _
                           GetType(DataTemplate), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.ItemTemplateProperty.DefaultMetadata.DefaultValue))



    Public Property SelectedIndex() As Integer
        Get
            Return GetValue(SelectedIndexProperty)
        End Get

        Set(ByVal value As Integer)
            SetValue(SelectedIndexProperty, value)
        End Set
    End Property

    Public Shared ReadOnly SelectedIndexProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectedIndex", _
                           GetType(Integer), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectedIndexProperty.DefaultMetadata.DefaultValue))



    Public Property SelectedValue() As Object
        Get
            Return GetValue(SelectedValueProperty)
        End Get

        Set(ByVal value As Object)
            SetValue(SelectedValueProperty, value)
        End Set
    End Property

    Public Shared ReadOnly SelectedValueProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectedValue", _
                           GetType(Object), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectedValueProperty.DefaultMetadata.DefaultValue))



    Public Property SelectedValuePath() As String
        Get
            Return GetValue(SelectedValuePathProperty)
        End Get

        Set(ByVal value As String)
            SetValue(SelectedValuePathProperty, value)
        End Set
    End Property

    Public Shared ReadOnly SelectedValuePathProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectedValuePath", _
                           GetType(String), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectedValuePathProperty.DefaultMetadata.DefaultValue))



    Public ReadOnly Property SelectionBoxItem() As Object
        Get
            Return combo.SelectionBoxItem
        End Get
    End Property

    Public Shared ReadOnly SelectionBoxItemProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectionBoxItem", _
                           GetType(Object), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectionBoxItemProperty.DefaultMetadata.DefaultValue))



    Public ReadOnly Property SelectionBoxItemStringFormat() As String
        Get
            Return combo.SelectionBoxItemStringFormat
        End Get
    End Property

    Public Shared ReadOnly SelectionBoxItemStringFormatProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectionBoxItemStringFormat", _
                           GetType(String), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectionBoxItemStringFormatProperty.DefaultMetadata.DefaultValue))



    Public ReadOnly Property SelectionBoxItemTemplate() As DataTemplate
        Get
            Return combo.SelectionBoxItemTemplate
        End Get
    End Property

    Public Shared ReadOnly SelectionBoxItemTemplateProperty As DependencyProperty = _
                           DependencyProperty.Register("SelectionBoxItemTemplate", _
                           GetType(DataTemplate), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.SelectionBoxItemTemplateProperty.DefaultMetadata.DefaultValue))



    Public Property StaysOpenOnEdit() As Boolean
        Get
            Return GetValue(StaysOpenOnEditProperty)
        End Get

        Set(ByVal value As Boolean)
            SetValue(StaysOpenOnEditProperty, value)
        End Set
    End Property

    Public Shared ReadOnly StaysOpenOnEditProperty As DependencyProperty = _
                           DependencyProperty.Register("StaysOpenOnEdit", _
                           GetType(Boolean), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.StaysOpenOnEditProperty.DefaultMetadata.DefaultValue))



    Public Property Text() As String
        Get
            Return GetValue(TextProperty)
        End Get

        Set(ByVal value As String)
            SetValue(TextProperty, value)
        End Set
    End Property

    Public Shared ReadOnly TextProperty As DependencyProperty = _
                           DependencyProperty.Register("Text", _
                           GetType(String), GetType(NullableComboBox), _
                           New FrameworkPropertyMetadata(ComboBox.TextProperty.DefaultMetadata.DefaultValue))
#End Region

#Region "NullPlaceholder class"
    ''' <summary>
    ''' Adding <c>Nothing</c> to the combo box's collection causes weird behaviour, so a
    ''' singleton instance of this class is used instead.
    ''' </summary>
    Class NullPlaceholder

        Private Shared _instance As New NullPlaceholder

        Public Shared ReadOnly Property Instance() As NullPlaceholder
            Get
                Return _instance
            End Get
        End Property

        Private Sub New()
            ' This is just to make it a singleton
        End Sub

        ''' <summary>
        ''' This is here so that if you don't define a a <c>DataTemplate</c> for this type
        ''' you will see a blank option instead of "NullableComboBox+NullPlaceholder".
        ''' </summary>
        Public Overrides Function ToString() As String
            Return Nothing
        End Function
    End Class
#End Region

End Class
