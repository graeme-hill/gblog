﻿Imports System.ComponentModel


Public Class NullableComboBoxTestModelView
    Implements INotifyPropertyChanged


    Private _numbers() As Integer
    Private _selectedNumber As Integer?

    Public Sub New()
        _numbers = New Integer() {1, 2, 3, 4, 5, 6, 7, 8, 9}
    End Sub

    Public Property SelectedNumber() As Integer?
        Get
            Return _selectedNumber
        End Get
        Set(ByVal value As Integer?)
            _selectedNumber = value
            RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs("SelectedNumber"))
        End Set
    End Property

    Public ReadOnly Property Numbers() As Integer()
        Get
            Return _numbers
        End Get
    End Property

    Public Event PropertyChanged(ByVal sender As Object, ByVal e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged
End Class
